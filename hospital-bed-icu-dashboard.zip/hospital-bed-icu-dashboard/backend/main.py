import os
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import JWTError, jwt
from passlib.context import CryptContext
from pydantic import BaseModel, Field

APP_SECRET = os.getenv("JWT_SECRET", "CHANGE-THIS-DEVELOPMENT-SECRET-BEFORE-DEPLOYMENT")
ALGORITHM = "HS256"
TOKEN_MINUTES = 60
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/token")

app = FastAPI(title="CareCapacity Analytics API", version="1.0.0",
              description="Academic demo API for fictional hospital bed availability.")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Demo-only account. For a real project, store users securely in a database.
DEMO_USER = {"username": "admin", "password_hash": pwd_context.hash("Hospital123!")}

beds = [
    {"id": 1, "hospital": "City General Hospital", "city": "Ahmedabad", "ward": "General", "total": 120, "available": 32},
    {"id": 2, "hospital": "City General Hospital", "city": "Ahmedabad", "ward": "ICU", "total": 24, "available": 5},
    {"id": 3, "hospital": "Sunrise Medical Centre", "city": "Gandhinagar", "ward": "General", "total": 90, "available": 27},
    {"id": 4, "hospital": "Sunrise Medical Centre", "city": "Gandhinagar", "ward": "ICU", "total": 18, "available": 4},
    {"id": 5, "hospital": "Riverbend Hospital", "city": "Vadodara", "ward": "General", "total": 150, "available": 41},
    {"id": 6, "hospital": "Riverbend Hospital", "city": "Vadodara", "ward": "ICU", "total": 30, "available": 6},
    {"id": 7, "hospital": "Community Care Hospital", "city": "Surat", "ward": "General", "total": 75, "available": 14},
    {"id": 8, "hospital": "Community Care Hospital", "city": "Surat", "ward": "ICU", "total": 16, "available": 2},
]

class BedUpdate(BaseModel):
    available: int = Field(ge=0)

def create_access_token(username: str) -> str:
    expires = datetime.now(timezone.utc) + timedelta(minutes=TOKEN_MINUTES)
    return jwt.encode({"sub": username, "exp": expires}, APP_SECRET, algorithm=ALGORITHM)

async def current_user(token: str = Depends(oauth2_scheme)):
    credentials_error = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or expired token",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, APP_SECRET, algorithms=[ALGORITHM])
        username: Optional[str] = payload.get("sub")
        if username != DEMO_USER["username"]:
            raise credentials_error
    except JWTError:
        raise credentials_error
    return username

@app.get("/")
def root():
    return {"message": "CareCapacity API is running", "docs": "/docs"}

@app.post("/auth/token")
def issue_token(form_data: OAuth2PasswordRequestForm = Depends()):
    if (form_data.username != DEMO_USER["username"] or
            not pwd_context.verify(form_data.password, DEMO_USER["password_hash"])):
        raise HTTPException(status_code=401, detail="Incorrect username or password",
                            headers={"WWW-Authenticate": "Bearer"})
    return {"access_token": create_access_token(form_data.username), "token_type": "bearer"}

@app.get("/me")
def read_me(username: str = Depends(current_user)):
    return {"username": username}

@app.get("/beds")
def get_beds(username: str = Depends(current_user)):
    return beds

@app.patch("/beds/{bed_id}")
def update_bed(bed_id: int, update: BedUpdate, username: str = Depends(current_user)):
    item = next((bed for bed in beds if bed["id"] == bed_id), None)
    if item is None:
        raise HTTPException(status_code=404, detail="Bed record not found")
    if update.available > item["total"]:
        raise HTTPException(status_code=400, detail="Available beds cannot exceed total beds")
    item["available"] = update.available
    return item

@app.get("/analytics/summary")
def analytics_summary(username: str = Depends(current_user)):
    total = sum(item["total"] for item in beds)
    available = sum(item["available"] for item in beds)
    occupied = total - available
    icu_items = [item for item in beds if item["ward"].lower() == "icu"]
    icu_total = sum(item["total"] for item in icu_items)
    icu_available = sum(item["available"] for item in icu_items)
    occupancy = round((occupied / total) * 100, 1) if total else 0
    by_ward = {}
    for item in beds:
        ward = item["ward"]
        by_ward.setdefault(ward, {"ward": ward, "total": 0, "available": 0, "occupied": 0})
        by_ward[ward]["total"] += item["total"]
        by_ward[ward]["available"] += item["available"]
        by_ward[ward]["occupied"] += item["total"] - item["available"]
    return {
        "total_beds": total,
        "available_beds": available,
        "occupied_beds": occupied,
        "icu_total": icu_total,
        "icu_available": icu_available,
        "occupancy_percent": occupancy,
        "by_ward": list(by_ward.values()),
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }
