import { configureStore } from '@reduxjs/toolkit'
import authReducer from '../features/auth/authSlice'
import bedsReducer from '../features/beds/bedsSlice'

export const store = configureStore({
  reducer: { auth: authReducer, beds: bedsReducer }
})
