import { useEffect, useMemo, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { BedDouble, Building2, Activity, LogOut, RefreshCw, Search, Siren, Users } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { logout } from '../features/auth/authSlice'
import { fetchBeds, fetchAnalytics, updateBed } from '../features/beds/bedsSlice'

function StatCard({ icon: Icon, label, value, helper, tone = 'blue' }) {
  return <article className="stat-card">
    <div className={`stat-icon ${tone}`}><Icon size={21}/></div>
    <p className="stat-label">{label}</p>
    <div className="stat-value">{value}</div>
    <p className="stat-helper">{helper}</p>
  </article>
}

export default function Dashboard() {
  const dispatch = useDispatch()
  const { items, analytics, status, error } = useSelector(state => state.beds)
  const username = useSelector(state => state.auth.username)
  const [query, setQuery] = useState('')
  const [ward, setWard] = useState('All wards')
  const [busyId, setBusyId] = useState(null)

  useEffect(() => {
    dispatch(fetchBeds())
    dispatch(fetchAnalytics())
  }, [dispatch])

  const filtered = useMemo(() => items.filter(item =>
    (ward === 'All wards' || item.ward === ward) &&
    `${item.hospital} ${item.ward} ${item.city}`.toLowerCase().includes(query.toLowerCase())
  ), [items, ward, query])

  const wards = ['All wards', ...new Set(items.map(item => item.ward))]
  const summary = analytics || { total_beds: 0, available_beds: 0, occupied_beds: 0, icu_total: 0, icu_available: 0, occupancy_percent: 0 }
  const chartData = items.map(item => ({ name: item.ward, Available: item.available, Occupied: item.total - item.available }))

  async function toggleBed(item) {
    setBusyId(item.id)
    await dispatch(updateBed({ id: item.id, available: item.available > 0 ? item.available - 1 : item.total }))
    await dispatch(fetchAnalytics())
    setBusyId(null)
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="sidebar-brand"><span className="brand-mark small"><Activity size={20}/></span><span>CareCapacity<small>HOSPITAL SYSTEMS</small></span></div>
      <div className="nav-label">WORKSPACE</div>
      <div className="nav-item active"><Activity size={18}/> Overview</div>
      <div className="nav-item"><BedDouble size={18}/> Bed availability</div>
      <div className="nav-item"><Siren size={18}/> ICU capacity</div>
      <div className="sidebar-bottom"><div className="avatar">{(username || 'A')[0].toUpperCase()}</div><div className="user-copy"><b>{username || 'Admin'}</b><span>Administrator</span></div><button className="icon-button" title="Log out" onClick={() => dispatch(logout())}><LogOut size={17}/></button></div>
    </aside>

    <main className="main-content">
      <header className="topbar">
        <div><span className="breadcrumb">Workspace /</span> <strong>Overview</strong></div>
        <div className="topbar-right"><span className="live-dot"></span><span>Demo data</span><button className="refresh-button" onClick={() => { dispatch(fetchBeds()); dispatch(fetchAnalytics()) }}><RefreshCw size={15}/> Refresh</button></div>
      </header>
      <section className="page-heading">
        <div><p className="eyebrow">CAPACITY MONITORING</p><h1>Hospital overview</h1><p className="muted">Monitor bed availability and critical care capacity across facilities.</p></div>
        <div className="date-chip"><Activity size={16}/> Sample environment</div>
      </section>

      {error && <div className="error-banner">{String(error)}. Check that the FastAPI server is running.</div>}
      {status === 'loading' && <p className="muted">Loading hospital data…</p>}

      <section className="stats-grid">
        <StatCard icon={BedDouble} label="Total beds" value={summary.total_beds} helper="Across listed wards" tone="blue"/>
        <StatCard icon={Users} label="Available beds" value={summary.available_beds} helper="Ready for admission" tone="green"/>
        <StatCard icon={Building2} label="Occupied beds" value={summary.occupied_beds} helper={`${summary.occupancy_percent}% occupancy`} tone="purple"/>
        <StatCard icon={Siren} label="ICU beds available" value={summary.icu_available} helper={`Of ${summary.icu_total} ICU beds`} tone="orange"/>
      </section>

      <section className="content-grid">
        <article className="panel chart-panel">
          <div className="panel-heading"><div><h2>Ward capacity</h2><p className="muted">Available versus occupied beds</p></div><span className="chart-legend"><i className="legend-green"></i> Available <i className="legend-blue"></i> Occupied</span></div>
          <div className="chart-area">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 10, left: -18, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e9edf4"/>
                <XAxis dataKey="name" tick={{ fill: '#6b7280', fontSize: 11 }} axisLine={false} tickLine={false}/>
                <YAxis tick={{ fill: '#6b7280', fontSize: 11 }} axisLine={false} tickLine={false}/>
                <Tooltip/>
                <Bar dataKey="Available" fill="#21a675" radius={[4,4,0,0]}/>
                <Bar dataKey="Occupied" fill="#4776e6" radius={[4,4,0,0]}/>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </article>

        <article className="panel occupancy-panel">
          <div className="panel-heading"><div><h2>Overall occupancy</h2><p className="muted">All listed beds</p></div></div>
          <div className="occupancy-circle" style={{ '--progress': `${Math.min(100, summary.occupancy_percent)}%` }}><div><strong>{summary.occupancy_percent}%</strong><span>occupied</span></div></div>
          <div className="occupancy-breakdown"><div><span><i className="legend-blue"></i> Occupied</span><b>{summary.occupied_beds}</b></div><div><span><i className="legend-green"></i> Available</span><b>{summary.available_beds}</b></div></div>
          <div className="info-note">Use this indicator to spot wards that may need capacity planning.</div>
        </article>
      </section>

      <section className="panel table-panel">
        <div className="panel-heading table-heading"><div><h2>Hospital bed inventory</h2><p className="muted">Fictional sample facilities and ward records</p></div>
          <div className="table-tools"><label className="search-box"><Search size={16}/><input placeholder="Search hospital or city" value={query} onChange={e => setQuery(e.target.value)}/></label>
            <select value={ward} onChange={e => setWard(e.target.value)} aria-label="Filter by ward">{wards.map(w => <option key={w}>{w}</option>)}</select>
          </div>
        </div>
        <div className="table-wrap"><table><thead><tr><th>Hospital / city</th><th>Ward</th><th>Total beds</th><th>Available</th><th>Occupied</th><th>Availability</th><th>Demo action</th></tr></thead>
          <tbody>{filtered.map(item => {
            const occupied = item.total - item.available
            const percent = item.total ? Math.round(occupied / item.total * 100) : 0
            return <tr key={item.id}><td><div className="hospital-name">{item.hospital}</div><div className="city-name">{item.city}</div></td><td><span className={`ward-tag ${item.ward === 'ICU' ? 'icu' : ''}`}>{item.ward}</span></td><td>{item.total}</td><td className="available-number">{item.available}</td><td>{occupied}</td><td><div className="availability-cell"><div className="mini-progress"><span style={{ width: `${100-percent}%` }}/></div><span>{100-percent}%</span></div></td><td><button className="small-button" disabled={busyId === item.id} onClick={() => toggleBed(item)}>{busyId === item.id ? 'Updating…' : item.available > 0 ? 'Simulate admit' : 'Reset demo'}</button></td></tr>
          })}</tbody></table>
          {filtered.length === 0 && <p className="empty-state">No records match your search.</p>}
        </div>
        <p className="table-footnote">“Simulate admit” changes demo availability only. No patient records are stored.</p>
      </section>
      <footer className="footer">CareCapacity • JavaScript PBL project • Sample data only</footer>
    </main>
  </div>
}
