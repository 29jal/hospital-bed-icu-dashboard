import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Navigate, useNavigate } from 'react-router-dom'
import { Activity, ShieldCheck } from 'lucide-react'
import { login } from '../features/auth/authSlice'

export default function Login() {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const { token, status, error } = useSelector(state => state.auth)
  const [username, setUsername] = useState('admin')
  const [password, setPassword] = useState('Hospital123!')

  if (token) return <Navigate to="/" replace />

  async function handleSubmit(event) {
    event.preventDefault()
    const result = await dispatch(login({ username, password }))
    if (login.fulfilled.match(result)) navigate('/')
  }

  return <main className="login-page">
    <section className="login-card">
      <div className="brand-mark"><Activity size={28} /></div>
      <p className="eyebrow">CARECAPACITY • HOSPITAL OPERATIONS</p>
      <h1>Welcome back</h1>
      <p className="muted">Sign in to monitor bed and ICU capacity.</p>
      <form onSubmit={handleSubmit} className="login-form">
        <label>Username<input value={username} onChange={e => setUsername(e.target.value)} required autoComplete="username" /></label>
        <label>Password<input type="password" value={password} onChange={e => setPassword(e.target.value)} required autoComplete="current-password" /></label>
        {error && <p className="error-message">{String(error)}</p>}
        <button className="primary-button" disabled={status === 'loading'}>{status === 'loading' ? 'Signing in…' : 'Sign in securely'}</button>
      </form>
      <div className="demo-note"><ShieldCheck size={16}/><span>Demo login: admin / Hospital123!</span></div>
      <p className="tiny muted">Student demonstration with fictional data. Not for clinical use.</p>
    </section>
  </main>
}
