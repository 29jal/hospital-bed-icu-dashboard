import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import api from '../../api'

export const login = createAsyncThunk('auth/login', async ({ username, password }, thunkAPI) => {
  try {
    const body = new URLSearchParams()
    body.append('username', username)
    body.append('password', password)
    const response = await api.post('/auth/token', body, {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    })
    localStorage.setItem('access_token', response.data.access_token)
    return { username, token: response.data.access_token }
  } catch (error) {
    return thunkAPI.rejectWithValue(error.response?.data?.detail || 'Login failed. Check your details and backend.')
  }
})

const authSlice = createSlice({
  name: 'auth',
  initialState: {
    token: localStorage.getItem('access_token'),
    username: localStorage.getItem('demo_username') || '',
    status: 'idle',
    error: null
  },
  reducers: {
    logout(state) {
      state.token = null
      state.username = ''
      state.error = null
      localStorage.removeItem('access_token')
      localStorage.removeItem('demo_username')
    }
  },
  extraReducers(builder) {
    builder
      .addCase(login.pending, state => { state.status = 'loading'; state.error = null })
      .addCase(login.fulfilled, (state, action) => {
        state.status = 'succeeded'
        state.token = action.payload.token
        state.username = action.payload.username
        localStorage.setItem('demo_username', action.payload.username)
      })
      .addCase(login.rejected, (state, action) => {
        state.status = 'failed'
        state.error = action.payload || 'Unable to log in'
      })
  }
})
export const { logout } = authSlice.actions
export default authSlice.reducer
