import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import api from '../../api'

export const fetchBeds = createAsyncThunk('beds/fetchBeds', async (_, thunkAPI) => {
  try {
    const response = await api.get('/beds')
    return response.data
  } catch (error) {
    return thunkAPI.rejectWithValue(error.response?.data?.detail || 'Could not load bed data')
  }
})

export const fetchAnalytics = createAsyncThunk('beds/fetchAnalytics', async (_, thunkAPI) => {
  try {
    const response = await api.get('/analytics/summary')
    return response.data
  } catch (error) {
    return thunkAPI.rejectWithValue(error.response?.data?.detail || 'Could not load analytics')
  }
})

export const updateBed = createAsyncThunk('beds/updateBed', async ({ id, available }, thunkAPI) => {
  try {
    const response = await api.patch(`/beds/${id}`, { available })
    return response.data
  } catch (error) {
    return thunkAPI.rejectWithValue(error.response?.data?.detail || 'Could not update bed')
  }
})

const bedsSlice = createSlice({
  name: 'beds',
  initialState: { items: [], analytics: null, status: 'idle', error: null },
  reducers: {},
  extraReducers(builder) {
    builder
      .addCase(fetchBeds.pending, state => { state.status = 'loading'; state.error = null })
      .addCase(fetchBeds.fulfilled, (state, action) => { state.status = 'succeeded'; state.items = action.payload })
      .addCase(fetchBeds.rejected, (state, action) => { state.status = 'failed'; state.error = action.payload })
      .addCase(fetchAnalytics.fulfilled, (state, action) => { state.analytics = action.payload })
      .addCase(updateBed.fulfilled, (state, action) => {
        const index = state.items.findIndex(item => item.id === action.payload.id)
        if (index !== -1) state.items[index] = action.payload
      })
      .addCase(updateBed.rejected, (state, action) => { state.error = action.payload })
  }
})
export default bedsSlice.reducer
