# Hospital Bed & ICU Availability Dashboard (PBL - JavaScript)

A student project using React + Redux Toolkit + React Router, JWT authentication, and an optional FastAPI analytics API.

## Features
- Login using a demo account
- JWT access token issued by FastAPI
- Protected dashboard page
- Dashboard summary cards and occupancy bar chart
- Search and ward filter for hospital/ward bed data
- Add/update bed records in the in-memory demo dataset
- FastAPI analytics endpoint
- Clear separation between frontend and backend

> Academic demo only. The sample data is fictional and stored in memory. Restarting the backend resets changes. Do not use for real clinical decisions or real patient data.

## Requirements
- Node.js LTS and npm
- Git
- Python 3.10+ (for optional FastAPI backend)

## Run frontend + backend

### 1. Backend
Open a terminal in the `backend` folder:

```bash
python -m venv .venv
```

Windows PowerShell:
```powershell
.\.venv\Scripts\Activate.ps1
```

Windows Command Prompt:
```bat
.venv\Scripts\activate
```

Install dependencies and start the API:
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

API docs: http://127.0.0.1:8000/docs

Demo login:
- Username: `admin`
- Password: `Hospital123!`

### 2. Frontend
Open a second terminal in the `frontend` folder:

```bash
npm install
npm run dev
```

Open the local URL shown by Vite (usually http://localhost:5173).

## Notes
- JWT secret is a development placeholder. Set `JWT_SECRET` to a long random value before deployment.
- The demo uses in-memory data, not a database. For a stronger submission, add SQLite/PostgreSQL persistence and role-based authorization.
- Never commit `.env` files or production secrets to GitHub.
